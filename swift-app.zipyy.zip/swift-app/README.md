# Swift: Next.js + Supabase + Google Maps (Phase 1 backend and map)

## 1. Create the project
```bash
npx create-next-app@latest swift --ts --app --src-dir --no-tailwind
cd swift
npm i @supabase/supabase-js @supabase/ssr @googlemaps/js-api-loader zod
npm i -D @types/google.maps
```
Copy `src/`, `supabase/` and `.env.example` from this folder into the project. Rename `.env.example` to `.env.local`.

## 2. Supabase
1. Create a project at supabase.com. Paste `supabase/schema.sql` in the SQL editor and run it.
2. Authentication → create your admin user, then run:
   `update profiles set role='admin' where id='<your-user-id>';`
   (Add a trigger or a signup step that creates a `profiles` row for each new user.)
3. Copy the URL, anon key and service-role key into `.env.local`.

## 3. Google Maps Platform (billing account required)
Create two keys:
- **Server key**: enable *Geocoding API* and *Routes API*. Restrict by IP. Goes in `GOOGLE_MAPS_SERVER_KEY`.
- **Browser key**: enable *Maps JavaScript API* only. Restrict to your domain. Goes in `NEXT_PUBLIC_GOOGLE_MAPS_BROWSER_KEY`.

## 4. Run and deploy
`npm run dev`, then deploy on Vercel and add the same variables in Project → Settings → Environment Variables.

## What works
- `POST /api/orders`: validates, computes the price on the server (flat delivery price + Express, both editable in `/admin`), geocodes both addresses (or uses exact GPS points), requests a real driving route (distance, time with traffic), saves the order. If the route fails, the order is still saved and the error is shown to the admin.
- `/admin/orders/[id]`: admin-only page with map (green pickup, red delivery, blue route, zoom and map controls, marker info windows), distance and time from Google, "Navigate to destination", copy address.
- `/order`: customer order form (flat price from the database, Express checkbox, optional exact GPS position, WhatsApp confirmation). `/track`: customer tracking by code + phone number (refreshes every 15 s, shows status only).
- `DriverTracker`: assigned driver taps Start, the browser asks permission, a position is stored every 10 s, 3 consecutive points off the route flag `off_route`, and the admin page shows a moving driver marker in realtime.

## Not built yet (next steps)
- Address search with Arabic/French/English autocomplete and nearby landmarks (Places API).
- Alternative routes display, remaining-distance ETA from the live driver position.
- Driver login screen and assignment UI, status-update RPC for drivers, profile-creation trigger.
- Rate limiting on `/api/orders`, automatic deletion of old driver locations (privacy).

## Admin and driver screens
- `/login`: email + password; redirects admins to `/admin`, drivers to `/driver`.
- `/admin`: orders list, change status, assign a driver, open the order map. `/driver`: the driver's own active deliveries; the order page has call buttons, "Navigate to destination", status buttons and GPS sharing.
- Create users in Supabase → Authentication, then set roles with the SQL comments at the end of `schema.sql`.

## Deploy (needed before phones can install it, HTTPS is required)
1. Push the project to GitHub. 2. On vercel.com choose "Add New → Project", import the repo. 3. Add every variable from `.env.local` in Settings → Environment Variables. 4. Deploy, then add your Vercel domain to the Google browser key's allowed referrers.

## Install on a phone (PWA)
- **Android (Chrome):** open the site → ⋮ menu → "Install app" / "Add to Home screen".
- **iPhone (Safari only):** open the site → Share button → "Add to Home Screen".
The order page shows an "Installer l'application" button (one tap on Android, step-by-step help on iPhone; hidden once installed).
Customers open `/order`, drivers `/driver`, admins `/admin`. The app caches nothing, so it needs internet.
