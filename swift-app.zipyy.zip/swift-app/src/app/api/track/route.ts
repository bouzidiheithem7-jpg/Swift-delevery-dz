import { NextResponse } from "next/server";
import { z } from "zod";
import { supabaseAdmin } from "@/lib/supabase/server";

const Body = z.object({ code: z.string().regex(/^SW-\d{4,8}$/i), phone: z.string().min(9).max(16) });
const digits = (s: string) => s.replace(/\D/g, "").slice(-9); // compare the last 9 digits

// Public tracking. The phone number is required so codes can't be guessed one by one.
// Returns status and price only: never coordinates, addresses or names.
export async function POST(req: Request) {
  const p = Body.safeParse(await req.json().catch(() => null));
  const notFound = NextResponse.json({ error: "Commande introuvable" }, { status: 404 });
  if (!p.success) return notFound;
  const { data: o } = await supabaseAdmin().from("orders")
    .select("code,status,price_da,customer_phone")
    .eq("code", p.data.code.toUpperCase()).single();
  if (!o || digits(o.customer_phone) !== digits(p.data.phone)) return notFound;
  return NextResponse.json({ code: o.code, status: o.status, price_da: o.price_da });
}
