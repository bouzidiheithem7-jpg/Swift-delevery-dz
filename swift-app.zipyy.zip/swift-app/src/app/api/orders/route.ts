import { NextResponse } from "next/server";
import { z } from "zod";
import { supabaseAdmin } from "@/lib/supabase/server";
import { computeRoute, geocode, type LatLng } from "@/lib/google";

const Pt = z.object({ lat: z.number().min(18).max(38), lng: z.number().min(-9).max(12) });
const Body = z.object({
  customer_name: z.string().min(2).max(80), customer_phone: z.string().regex(/^[0-9 +]{9,16}$/),
  recipient_name: z.string().max(80).optional(), recipient_phone: z.string().max(16).optional(),
  pickup_address: z.string().min(3).max(200), dest_address: z.string().min(3).max(200),
  pickup: Pt.optional(), dest: Pt.optional(), // exact points if the customer shared GPS
  express: z.boolean().default(false),
});

export async function POST(req: Request) {
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success) return NextResponse.json({ error: "Données invalides", details: p.error.flatten() }, { status: 400 });
  const b = p.data, db = supabaseAdmin();

  // Price is computed on the server, never trusted from the client.
  const { data: rows } = await db.from("settings").select("key,value").in("key", ["delivery_price_da", "express_surcharge_da"]);
  const cfg = Object.fromEntries((rows ?? []).map((r) => [r.key, Number(r.value)]));
  const price = (cfg.delivery_price_da ?? 200) + (b.express ? (cfg.express_surcharge_da ?? 100) : 0);

  let route: Record<string, unknown> = {}, routeError: string | null = null;
  try {
    const a: LatLng = b.pickup ?? (await geocode(b.pickup_address));
    const d: LatLng = b.dest ?? (await geocode(b.dest_address));
    const r = await computeRoute(a, d);
    route = { pickup_lat: a.lat, pickup_lng: a.lng, dest_lat: d.lat, dest_lng: d.lng,
      route_distance_m: r.distance_m, route_duration_s: r.duration_s, route_polyline: r.polyline };
  } catch (e) { routeError = (e as Error).message; }

  const { data, error } = await db.from("orders").insert({
    customer_name: b.customer_name, customer_phone: b.customer_phone, recipient_name: b.recipient_name, recipient_phone: b.recipient_phone,
    pickup_address: b.pickup_address, dest_address: b.dest_address,
    express: b.express, price_da: price, route_error: routeError, ...route,
  }).select("code").single();
  if (error) return NextResponse.json({ error: "Création impossible" }, { status: 500 });
  return NextResponse.json({ code: data.code, price_da: price, routeError }); // order is saved even if the route failed
}
