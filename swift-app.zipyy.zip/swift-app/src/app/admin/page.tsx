import "../swift.css";
import Link from "next/link";
import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase/server";
import OrderControls from "@/components/OrderControls";
import PriceSettings from "@/components/PriceSettings";

export default async function Admin() {
  const sb = await supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) redirect("/login");
  const { data: me } = await sb.from("profiles").select("role").eq("id", user.id).single();
  if (me?.role !== "admin") redirect("/");
  const { data: orders } = await sb.from("orders")
    .select("id,code,customer_name,customer_phone,dest_address,price_da,status,off_route,driver_id").order("created_at", { ascending: false }).limit(100);
  const { data: drivers } = await sb.from("profiles").select("id,full_name").eq("role", "driver");
  const { data: st } = await sb.from("settings").select("key,value");
  const cfg = Object.fromEntries((st ?? []).map((r) => [r.key, Number(r.value)]));
  const list = orders ?? [];
  const delivered = list.filter((o) => o.status === "delivered");

  return (<main className="sw" style={{ maxWidth: 1000 }}><h1>Administration</h1>
    <div className="card"><p>100 dernières commandes : {list.length} · en attente : {list.filter((o) => o.status === "pending").length} · livrées : {delivered.length} · chiffre d'affaires livré : {delivered.reduce((a, o) => a + o.price_da, 0)} DA</p></div>
    <PriceSettings price={cfg.delivery_price_da ?? 200} express={cfg.express_surcharge_da ?? 100} />
    <div className="card" style={{ marginTop: 14, overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
        <thead><tr style={{ textAlign: "left" }}><th>Code</th><th>Client</th><th>Destination</th><th>Prix</th><th>Statut / livreur</th></tr></thead>
        <tbody>{list.map((o) => (<tr key={o.id} style={{ borderTop: "1px solid var(--bd)" }}>
          <td><Link href={`/admin/orders/${o.id}`} style={{ color: "#7aa2ff" }}>{o.code}</Link>{o.off_route && " ⚠️"}</td>
          <td>{o.customer_name}<br /><small>{o.customer_phone}</small></td><td>{o.dest_address}</td><td>{o.price_da} DA</td>
          <td><OrderControls id={o.id} status={o.status} driverId={o.driver_id} drivers={drivers ?? []} /></td></tr>))}</tbody>
      </table></div></main>);
}
