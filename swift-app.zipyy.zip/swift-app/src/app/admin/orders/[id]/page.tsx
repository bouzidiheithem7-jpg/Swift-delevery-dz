import { redirect, notFound } from "next/navigation";
import { supabaseServer } from "@/lib/supabase/server";
import RouteMap from "@/components/RouteMap";
import CopyButton from "@/components/CopyButton";
import OrderControls from "@/components/OrderControls";

export default async function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params, sb = await supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) redirect("/login");
  const { data: me } = await sb.from("profiles").select("role").eq("id", user.id).single();
  if (me?.role !== "admin") redirect("/"); // admins only (RLS enforces it too)
  const { data: o } = await sb.from("orders").select("*, driver:profiles!orders_driver_id_fkey(full_name)").eq("id", id).single();
  if (!o) notFound();
  const { data: drivers } = await sb.from("profiles").select("id,full_name").eq("role", "driver");

  const hasRoute = o.route_polyline && o.pickup_lat != null;
  const dest = o.dest_lat != null ? `${o.dest_lat},${o.dest_lng}` : `${o.dest_address}, Sidi Bel Abbès, Algérie`;
  const origin = o.pickup_lat != null ? `${o.pickup_lat},${o.pickup_lng}` : `${o.pickup_address}, Sidi Bel Abbès, Algérie`;
  const nav = `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(dest)}&travelmode=driving`;

  return (
    <main style={{ maxWidth: 900, margin: "auto", padding: 16 }}>
      <h1>{o.code} · {o.status}</h1>
      {o.off_route && <p role="alert">⚠️ Le livreur s'est écarté de l'itinéraire.</p>}
      <p>{o.customer_name} · {o.customer_phone} · Livreur : {o.driver?.full_name ?? "non assigné"}</p>
      <p>Retrait : {o.pickup_address}<br />Livraison : {o.dest_address}</p>
      <p>Prix : {o.price_da} DA{hasRoute && ` · ${(o.route_distance_m / 1000).toFixed(1)} km · ≈ ${Math.round(o.route_duration_s / 60)} min`}</p>
      <OrderControls id={o.id} status={o.status} driverId={o.driver_id} drivers={drivers ?? []} />
      {hasRoute
        ? <RouteMap orderId={o.id} pickup={{ lat: o.pickup_lat, lng: o.pickup_lng }} dest={{ lat: o.dest_lat, lng: o.dest_lng }} polyline={o.route_polyline} pickupAddress={o.pickup_address} destAddress={o.dest_address} />
        : <p role="alert">Itinéraire non calculé : {o.route_error ?? "adresses incomplètes"}. Vous pouvez quand même ouvrir Google Maps.</p>}
      <p><a href={nav} target="_blank" rel="noopener noreferrer">Navigate to destination</a> <CopyButton text={o.dest_address} /></p>
    </main>
  );
}
