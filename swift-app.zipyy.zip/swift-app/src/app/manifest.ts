import type { MetadataRoute } from "next";
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Swift Livraison", short_name: "Swift", description: "Livraison rapide à Sidi Bel Abbès", lang: "fr",
    start_url: "/order", scope: "/", display: "standalone", background_color: "#000000", theme_color: "#000000",
    icons: [{ src: "/icon-192.png", sizes: "192x192", type: "image/png" }, { src: "/icon-512.png", sizes: "512x512", type: "image/png" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" }],
    shortcuts: [{ name: "Suivre ma commande", url: "/track" }, { name: "Livreur", url: "/driver" }, { name: "Admin", url: "/admin" }],
  };
}
