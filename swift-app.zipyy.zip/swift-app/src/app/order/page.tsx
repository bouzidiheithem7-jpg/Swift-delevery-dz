"use client";
import "../swift.css";
import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/browser";
import InstallButton from "@/components/InstallButton";

type Pt = { lat: number; lng: number } | undefined;

export default function OrderPage() {
  const [base, setBase] = useState(200), [extra, setExtra] = useState(100), [express, setExpress] = useState(false);
  const [f, setF] = useState({ customer_name: "", customer_phone: "", recipient_name: "", recipient_phone: "", pickup_address: "", dest_address: "" });
  const [pp, setPp] = useState<Pt>(), [dp, setDp] = useState<Pt>();
  const [err, setErr] = useState(""), [busy, setBusy] = useState(false), [done, setDone] = useState<{ code: string; price_da: number }>();

  useEffect(() => {
    supabaseBrowser().from("settings").select("key,value").in("key", ["delivery_price_da", "express_surcharge_da"]).then(({ data }) => {
      data?.forEach((r) => (r.key === "delivery_price_da" ? setBase : setExtra)(Number(r.value)));
    });
  }, []);

  const price = base + (express ? extra : 0); // display only; the server recomputes it
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  const locate = (setPt: (p: Pt) => void) => navigator.geolocation.getCurrentPosition(
    (r) => setPt({ lat: r.coords.latitude, lng: r.coords.longitude }), () => setErr("Position refusée. L'adresse écrite sera utilisée."), { enableHighAccuracy: true, timeout: 10000 });

  async function submit() {
    setErr(""); setBusy(true);
    const res = await fetch("/api/orders", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...f, recipient_name: f.recipient_name || undefined, recipient_phone: f.recipient_phone || undefined, pickup: pp, dest: dp, express }) });
    const j = await res.json(); setBusy(false);
    if (!res.ok) return setErr(j.error === "Données invalides" ? "Vérifiez les champs (nom, téléphone, adresses)." : j.error);
    setDone(j);
  }

  if (done) {
    const wa = `https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER}?text=${encodeURIComponent(`Bonjour Swift, commande ${done.code} (${done.price_da} DA).`)}`;
    return (<main className="sw"><h1>Merci !</h1><div className="card"><p>Commande <b>{done.code}</b> enregistrée : {done.price_da} DA.</p>
      <p>Gardez ce code et votre numéro de téléphone pour le suivi.</p>
      <a className="btn" href={wa} target="_blank" rel="noopener noreferrer">Confirmer sur WhatsApp</a>
      <a className="btn" style={{ background: "var(--bd)" }} href="/track">Suivre ma commande</a></div></main>);
  }

  return (
    <main className="sw"><h1>Commander une livraison</h1>
      <InstallButton />
      <div className="card">
        <label>Adresse de retrait</label><input value={f.pickup_address} onChange={set("pickup_address")} placeholder="Rue, quartier, repère" />
        <button type="button" className="alt" onClick={() => locate(setPp)}>📍 Utiliser ma position pour le retrait</button>
        {pp && <small>✓ Position exacte enregistrée.</small>}
        <label>Adresse de livraison</label><input value={f.dest_address} onChange={set("dest_address")} placeholder="Rue, quartier, repère" />
        <button type="button" className="alt" onClick={() => locate(setDp)}>📍 Utiliser ma position pour la livraison</button>
        {dp && <small>✓ Position exacte enregistrée.</small>}
        <label>Votre nom</label><input value={f.customer_name} onChange={set("customer_name")} />
        <label>Votre téléphone</label><input inputMode="tel" value={f.customer_phone} onChange={set("customer_phone")} />
        <label>Destinataire (facultatif)</label><input value={f.recipient_name} onChange={set("recipient_name")} placeholder="Nom" />
        <input style={{ marginTop: 8 }} inputMode="tel" value={f.recipient_phone} onChange={set("recipient_phone")} placeholder="Téléphone du destinataire" />
        <label><input type="checkbox" style={{ width: "auto", marginRight: 8 }} checked={express} onChange={(e) => setExpress(e.target.checked)} />Express, moins de 15 min (+{extra} DA)</label>
        <p>Prix</p><div className="price">{price} DA</div>
        {err && <p className="err" role="alert">{err}</p>}
        <button disabled={busy} onClick={submit}>{busy ? "Envoi…" : "Confirmer la commande"}</button>
      </div></main>
  );
}
