import type { Metadata, Viewport } from "next";
import PwaRegister from "@/components/PwaRegister";

export const metadata: Metadata = {
  title: "Swift – Livraison à Sidi Bel Abbès", description: "Livraison rapide, un prix simple par livraison.",
  appleWebApp: { capable: true, title: "Swift", statusBarStyle: "black-translucent" }, icons: { apple: "/icon-192.png" },
};
export const viewport: Viewport = { themeColor: "#000000", viewportFit: "cover" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="fr"><body style={{ margin: 0, background: "#000" }}>{children}<PwaRegister /></body></html>);
}
