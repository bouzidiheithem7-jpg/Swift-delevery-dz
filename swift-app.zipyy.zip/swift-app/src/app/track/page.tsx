"use client";
import "../swift.css";
import { useCallback, useEffect, useState } from "react";
import { STEPS } from "@/lib/status";

type R = { code: string; status: string; price_da: number };

export default function TrackPage() {
  const [code, setCode] = useState(""), [phone, setPhone] = useState(""), [r, setR] = useState<R>(), [err, setErr] = useState("");

  const search = useCallback(async () => {
    const res = await fetch("/api/track", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code, phone }) });
    if (!res.ok) { setR(undefined); return setErr("Aucune commande trouvée. Vérifiez le code et le téléphone."); }
    setErr(""); setR(await res.json());
  }, [code, phone]);

  useEffect(() => { if (!r) return; const t = setInterval(search, 15000); return () => clearInterval(t); }, [r, search]); // refresh every 15 s

  const idx = STEPS.findIndex(([s]) => s === r?.status);
  return (
    <main className="sw"><h1>Suivre ma commande</h1>
      <div className="card">
        <label>Code de commande</label><input value={code} onChange={(e) => setCode(e.target.value)} placeholder="SW-1001" />
        <label>Téléphone utilisé pour la commande</label><input inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
        <button onClick={search}>Rechercher</button>
        {err && <p className="err" role="alert">{err}</p>}
        {r && (<>
          <p style={{ marginTop: 14 }}>Commande {r.code} · {r.price_da} DA</p>
          {r.status === "cancelled" ? <p className="err">Commande annulée.</p>
            : STEPS.map(([s, label], i) => <div key={s} className={`step ${i <= idx ? "d" : ""}`}>{i <= idx ? "✓ " : ""}{label}</div>)}
          <small>Statut mis à jour par l'équipe. La position du livreur n'est pas partagée avec les clients dans cette version.</small>
        </>)}
      </div></main>
  );
}
