import "../../../swift.css";
import { redirect, notFound } from "next/navigation";
import { supabaseServer } from "@/lib/supabase/server";
import DriverStatus from "@/components/DriverStatus";
import DriverTracker from "@/components/DriverTracker";

export default async function DriverOrder({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params, sb = await supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) redirect("/login");
  const { data: o } = await sb.from("orders").select("*").eq("id", id).eq("driver_id", user.id).single(); // RLS + filter: own orders only
  if (!o) notFound();
  const pt = (lat: number | null, lng: number | null, addr: string) => lat != null ? `${lat},${lng}` : `${addr}, Sidi Bel Abbès, Algérie`;
  const nav = `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(pt(o.pickup_lat, o.pickup_lng, o.pickup_address))}&destination=${encodeURIComponent(pt(o.dest_lat, o.dest_lng, o.dest_address))}&travelmode=driving`;
  return (<main className="sw"><h1>{o.code}</h1><div className="card">
    <p>Retrait : {o.pickup_address}<br />Livraison : {o.dest_address}</p>
    <p>Client : {o.customer_name} · <a href={`tel:${o.customer_phone}`} style={{ color: "#7aa2ff" }}>Appeler</a></p>
    {o.recipient_phone && <p>Destinataire : {o.recipient_name} · <a href={`tel:${o.recipient_phone}`} style={{ color: "#7aa2ff" }}>Appeler</a></p>}
    <p>À encaisser : <b>{o.price_da} DA</b> (espèces)</p>
    <a className="btn" href={nav} target="_blank" rel="noopener noreferrer">Navigate to destination</a>
    <DriverStatus id={o.id} status={o.status} />
    {o.route_polyline && <DriverTracker orderId={o.id} driverId={user.id} polyline={o.route_polyline} />}
  </div></main>);
}
