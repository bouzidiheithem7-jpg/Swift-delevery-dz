import "../swift.css";
import Link from "next/link";
import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase/server";

export default async function Driver() {
  const sb = await supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) redirect("/login");
  const { data: me } = await sb.from("profiles").select("role").eq("id", user.id).single();
  if (me?.role !== "driver") redirect("/");
  const { data: orders } = await sb.from("orders").select("id,code,dest_address,price_da,status").eq("driver_id", user.id)
    .not("status", "in", "(delivered,cancelled)").order("created_at");
  return (<main className="sw"><h1>Mes livraisons</h1>
    {(orders ?? []).length === 0 && <p>Aucune livraison assignée.</p>}
    {(orders ?? []).map((o) => (<Link key={o.id} href={`/driver/orders/${o.id}`} className="card" style={{ display: "block", marginBottom: 10, color: "inherit", textDecoration: "none" }}>
      <b>{o.code}</b> · {o.price_da} DA<br /><small>{o.dest_address}</small></Link>))}
  </main>);
}
