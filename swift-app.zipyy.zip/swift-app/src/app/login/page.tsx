"use client";
import "../swift.css";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/browser";

export default function Login() {
  const [email, setEmail] = useState(""), [pw, setPw] = useState(""), [err, setErr] = useState(""), router = useRouter();
  async function go() {
    const sb = supabaseBrowser();
    const { data, error } = await sb.auth.signInWithPassword({ email, password: pw });
    if (error || !data.user) return setErr("Email ou mot de passe incorrect.");
    const { data: me } = await sb.from("profiles").select("role").eq("id", data.user.id).single();
    router.push(me?.role === "admin" ? "/admin" : me?.role === "driver" ? "/driver" : "/order");
    router.refresh();
  }
  return (<main className="sw"><h1>Connexion</h1><div className="card">
    <label>Email</label><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
    <label>Mot de passe</label><input type="password" value={pw} onChange={(e) => setPw(e.target.value)} />
    {err && <p className="err" role="alert">{err}</p>}<button onClick={go}>Se connecter</button></div></main>);
}
