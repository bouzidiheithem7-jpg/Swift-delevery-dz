export const STEPS = [
  ["pending", "En attente"], ["confirmed", "Confirmée"], ["driver_on_the_way", "Livreur en route"],
  ["picked_up", "Récupérée"], ["in_transit", "En transit"], ["delivered", "Livrée"],
] as const;
