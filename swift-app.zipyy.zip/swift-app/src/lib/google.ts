// Server-side only. Uses GOOGLE_MAPS_SERVER_KEY.
const KEY = process.env.GOOGLE_MAPS_SERVER_KEY!;
export type LatLng = { lat: number; lng: number };

export async function geocode(address: string, lang = "fr"): Promise<LatLng> {
  const q = new URLSearchParams({ address: `${address}, Sidi Bel Abbès`, components: "country:DZ", region: "dz", language: lang, key: KEY });
  const r = await (await fetch(`https://maps.googleapis.com/maps/api/geocode/json?${q}`)).json();
  if (r.status !== "OK" || !r.results?.[0]) throw new Error(`Adresse introuvable (${r.status})`);
  const { lat, lng } = r.results[0].geometry.location;
  return { lat, lng };
}

export async function computeRoute(a: LatLng, b: LatLng) {
  const loc = (p: LatLng) => ({ location: { latLng: { latitude: p.lat, longitude: p.lng } } });
  const res = await fetch("https://routes.googleapis.com/directions/v2:computeRoutes", {
    method: "POST",
    headers: {
      "Content-Type": "application/json", "X-Goog-Api-Key": KEY,
      "X-Goog-FieldMask": "routes.distanceMeters,routes.duration,routes.polyline.encodedPolyline",
    },
    body: JSON.stringify({ origin: loc(a), destination: loc(b), travelMode: "DRIVE", routingPreference: "TRAFFIC_AWARE", languageCode: "fr" }),
  });
  const j = await res.json();
  const r = j.routes?.[0];
  if (!res.ok || !r) throw new Error(j.error?.message ?? "Itinéraire impossible");
  return { distance_m: r.distanceMeters as number, duration_s: parseInt(r.duration) as number, polyline: r.polyline.encodedPolyline as string };
}
