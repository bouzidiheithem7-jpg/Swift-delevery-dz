"use client";
import { useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/browser";

export default function PriceSettings({ price, express }: { price: number; express: number }) {
  const [p, setP] = useState(price), [x, setX] = useState(express);
  async function save() {
    const { error } = await supabaseBrowser().from("settings").upsert([{ key: "delivery_price_da", value: p }, { key: "express_surcharge_da", value: x }]);
    alert(error ? "Modification refusée." : "Prix enregistrés.");
  }
  return (<div className="card"><b>Tarifs (DA)</b>
    <label>Prix d'une livraison</label><input type="number" value={p} onChange={(e) => setP(+e.target.value)} />
    <label>Supplément Express</label><input type="number" value={x} onChange={(e) => setX(+e.target.value)} />
    <button onClick={save}>Enregistrer</button></div>);
}
