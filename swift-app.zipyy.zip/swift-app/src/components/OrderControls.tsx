"use client";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/browser";

const STATUS: [string, string][] = [["pending", "En attente"], ["confirmed", "Confirmée"], ["driver_on_the_way", "Livreur en route"],
  ["picked_up", "Récupérée"], ["in_transit", "En transit"], ["delivered", "Livrée"], ["cancelled", "Annulée"]];

export default function OrderControls({ id, status, driverId, drivers }: { id: string; status: string; driverId: string | null; drivers: { id: string; full_name: string | null }[] }) {
  const router = useRouter(), sb = supabaseBrowser();
  async function update(patch: Record<string, unknown>) {
    const { error } = await sb.from("orders").update(patch).eq("id", id);
    if (error) alert("Modification refusée."); else router.refresh();
  }
  return (<span style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
    <select defaultValue={status} onChange={(e) => update({ status: e.target.value })}>{STATUS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
    <select defaultValue={driverId ?? ""} onChange={(e) => update({ driver_id: e.target.value || null })}>
      <option value="">Sans livreur</option>{drivers.map((d) => <option key={d.id} value={d.id}>{d.full_name ?? d.id.slice(0, 6)}</option>)}</select>
  </span>);
}
