"use client";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/browser";

const NEXT: [string, string][] = [["driver_on_the_way", "Je suis en route"], ["picked_up", "Colis récupéré"], ["in_transit", "En transit"], ["delivered", "Livré"]];
export default function DriverStatus({ id, status }: { id: string; status: string }) {
  const router = useRouter();
  async function set(s: string) {
    const { error } = await supabaseBrowser().rpc("driver_set_status", { p_order: id, p_status: s });
    if (error) alert("Impossible de changer le statut."); else router.refresh();
  }
  return (<div>{NEXT.map(([s, l]) => <button key={s} className={s === status ? "alt" : ""} disabled={s === status} onClick={() => set(s)}>{l}{s === status ? " ✓" : ""}</button>)}</div>);
}
