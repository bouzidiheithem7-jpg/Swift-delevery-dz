"use client";
import { useEffect, useRef, useState } from "react";
import { Loader } from "@googlemaps/js-api-loader";
import { supabaseBrowser } from "@/lib/supabase/browser";

// Shown to the assigned driver. GPS is sent only after the driver taps "Start" and the browser grants permission.
export default function DriverTracker({ orderId, driverId, polyline }: { orderId: string; driverId: string; polyline: string }) {
  const [on, setOn] = useState(false), [msg, setMsg] = useState("Le partage de position est désactivé.");
  const last = useRef(0), misses = useRef(0);

  useEffect(() => {
    if (!on) return;
    const sb = supabaseBrowser();
    let watch = 0, cancelled = false;
    new Loader({ apiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_BROWSER_KEY!, version: "weekly", libraries: ["geometry"] }).load().then((g) => {
      if (cancelled) return;
      const route = new g.maps.Polyline({ path: g.maps.geometry.encoding.decodePath(polyline) });
      watch = navigator.geolocation.watchPosition(async (pos) => {
        const now = Date.now(); if (now - last.current < 10_000) return; last.current = now; // one point / 10 s
        const { latitude: lat, longitude: lng } = pos.coords;
        await sb.from("driver_locations").insert({ order_id: orderId, driver_id: driverId, lat, lng });
        const onRoute = g.maps.geometry.poly.isLocationOnEdge(new g.maps.LatLng(lat, lng), route, 0.0006); // about 65 m
        misses.current = onRoute ? 0 : misses.current + 1;
        if (misses.current >= 3) { await sb.from("orders").update({ off_route: true }).eq("id", orderId); setMsg("Vous semblez hors itinéraire. L'administrateur est prévenu."); }
        else setMsg("Position partagée.");
      }, () => { setMsg("Permission de localisation refusée."); setOn(false); }, { enableHighAccuracy: true, maximumAge: 5000 });
    });
    return () => { cancelled = true; navigator.geolocation.clearWatch(watch); };
  }, [on, orderId, driverId, polyline]);

  return (<div><p>{msg}</p><button onClick={() => setOn(!on)}>{on ? "Arrêter le partage" : "Démarrer le partage de position"}</button></div>);
}
