"use client";
import { useEffect, useRef } from "react";
import { Loader } from "@googlemaps/js-api-loader";
import { supabaseBrowser } from "@/lib/supabase/browser";

type P = { lat: number; lng: number };
type Props = { orderId: string; pickup: P; dest: P; polyline: string; pickupAddress: string; destAddress: string };

export default function RouteMap({ orderId, pickup, dest, polyline, pickupAddress, destAddress }: Props) {
  const el = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const sb = supabaseBrowser();
    let channel: ReturnType<typeof sb.channel> | undefined;
    new Loader({ apiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_BROWSER_KEY!, version: "weekly", libraries: ["geometry"] }).load().then((g) => {
      const map = new g.maps.Map(el.current!, { center: pickup, zoom: 13, zoomControl: true, fullscreenControl: true, streetViewControl: true, mapTypeControl: true });
      const info = new g.maps.InfoWindow();
      const dot = (c: string) => ({ path: g.maps.SymbolPath.CIRCLE, scale: 9, fillColor: c, fillOpacity: 1, strokeColor: "#fff", strokeWeight: 2 });
      const mk = (pos: P, color: string, title: string, text: string) => {
        const m = new g.maps.Marker({ map, position: pos, title, icon: dot(color) });
        m.addListener("click", () => { info.setContent(`<b>${title}</b><br>${text.replace(/</g, "&lt;")}`); info.open(map, m); });
      };
      mk(pickup, "#22c55e", "Retrait", pickupAddress);   // green
      mk(dest, "#ef4444", "Livraison", destAddress);     // red
      const path = g.maps.geometry.encoding.decodePath(polyline);
      new g.maps.Polyline({ map, path, strokeColor: "#2f6df6", strokeWeight: 6, strokeOpacity: 0.9 }); // blue route
      const bounds = new g.maps.LatLngBounds(); path.forEach((p) => bounds.extend(p)); map.fitBounds(bounds);

      // Driver marker: ONLY real positions sent by the assigned driver's phone.
      let driver: google.maps.Marker | undefined;
      channel = sb.channel(`loc-${orderId}`).on("postgres_changes",
        { event: "INSERT", schema: "public", table: "driver_locations", filter: `order_id=eq.${orderId}` },
        ({ new: r }) => {
          const pos = { lat: r.lat, lng: r.lng };
          if (!driver) driver = new g.maps.Marker({ map, position: pos, title: "Livreur", icon: { path: g.maps.SymbolPath.FORWARD_CLOSED_ARROW, scale: 6, fillColor: "#f59e0b", fillOpacity: 1, strokeColor: "#000", strokeWeight: 1 } });
          else driver.setPosition(pos);
        }).subscribe();
    });
    return () => { if (channel) sb.removeChannel(channel); };
  }, [orderId, pickup, dest, polyline, pickupAddress, destAddress]);
  return <div ref={el} style={{ width: "100%", height: "min(70vh, 520px)", borderRadius: 16 }} />;
}
