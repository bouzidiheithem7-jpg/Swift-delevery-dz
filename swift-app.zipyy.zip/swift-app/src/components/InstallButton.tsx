"use client";
import { useEffect, useState } from "react";

type InstallEvent = Event & { prompt: () => Promise<void> };

// Android/Chrome: one-tap install prompt. iPhone: shows the Share → Add to Home Screen steps (Apple has no install prompt).
export default function InstallButton() {
  const [ev, setEv] = useState<InstallEvent | null>(null), [ios, setIos] = useState(false), [hide, setHide] = useState(true), [help, setHelp] = useState(false);

  useEffect(() => {
    const standalone = window.matchMedia("(display-mode: standalone)").matches || (navigator as Navigator & { standalone?: boolean }).standalone;
    if (standalone) return; // already installed: show nothing
    setIos(/iphone|ipad|ipod/i.test(navigator.userAgent)); setHide(false);
    const onPrompt = (e: Event) => { e.preventDefault(); setEv(e as InstallEvent); };
    const onInstalled = () => setHide(true);
    window.addEventListener("beforeinstallprompt", onPrompt); window.addEventListener("appinstalled", onInstalled);
    return () => { window.removeEventListener("beforeinstallprompt", onPrompt); window.removeEventListener("appinstalled", onInstalled); };
  }, []);

  if (hide) return null;
  async function click() { if (ev) { await ev.prompt(); setEv(null); } else setHelp(!help); }

  return (<div>
    <button type="button" className="alt" onClick={click}>📲 Installer l'application</button>
    {help && <p>{ios
      ? "Dans Safari : appuyez sur le bouton Partager, puis sur « Sur l'écran d'accueil ». (Cela ne marche pas depuis un autre navigateur.)"
      : "Ouvrez le menu ⋮ de votre navigateur, puis appuyez sur « Installer l'application » ou « Ajouter à l'écran d'accueil »."}</p>}
  </div>);
}
