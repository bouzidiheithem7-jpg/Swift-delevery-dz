"use client";
export default function CopyButton({ text }: { text: string }) {
  return <button onClick={() => navigator.clipboard.writeText(text)}>Copier l'adresse</button>;
}
