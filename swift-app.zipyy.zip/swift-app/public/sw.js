// Minimal service worker: makes the app installable. It caches nothing, so private order data is never stored offline.
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (e) => e.waitUntil(clients.claim()));
self.addEventListener("fetch", () => {});
