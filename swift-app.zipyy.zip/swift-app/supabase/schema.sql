-- Swift: run in Supabase SQL editor
create table profiles (
  id uuid primary key references auth.users on delete cascade,
  role text not null default 'customer' check (role in ('customer','driver','admin')),
  full_name text, phone text
);
create function is_admin() returns boolean language sql security definer stable as $$
  select exists(select 1 from profiles where id = auth.uid() and role = 'admin') $$;

create table settings (key text primary key, value jsonb not null);
insert into settings values ('delivery_price_da','200'),('express_surcharge_da','100');

create type order_status as enum ('pending','confirmed','driver_on_the_way','picked_up','in_transit','delivered','cancelled');
create sequence order_seq start 1001;
create table orders (
  id uuid primary key default gen_random_uuid(),
  code text unique not null default ('SW-' || nextval('order_seq')),
  customer_id uuid references profiles,
  customer_name text not null, customer_phone text not null,
  recipient_name text, recipient_phone text,
  pickup_address text not null, dest_address text not null,
  pickup_lat double precision, pickup_lng double precision,
  dest_lat double precision, dest_lng double precision,
  route_distance_m int, route_duration_s int, route_polyline text, route_error text,
  express bool not null default false,
  price_da int not null,
  status order_status not null default 'pending',
  driver_id uuid references profiles,
  off_route bool not null default false,
  created_at timestamptz not null default now()
);
create table driver_locations (
  id bigserial primary key,
  order_id uuid not null references orders on delete cascade,
  driver_id uuid not null references profiles,
  lat double precision not null, lng double precision not null,
  recorded_at timestamptz not null default now()
);

alter table profiles enable row level security;
alter table settings enable row level security;
alter table orders enable row level security;
alter table driver_locations enable row level security;

create policy "own profile" on profiles for select using (id = auth.uid() or is_admin());
create policy "settings read" on settings for select using (true);
create policy "settings admin" on settings for all using (is_admin()) with check (is_admin());

-- Orders are INSERTED only by the server (service role) via /api/orders.
create policy "orders read" on orders for select using (is_admin() or customer_id = auth.uid() or driver_id = auth.uid());
create policy "orders admin write" on orders for update using (is_admin());
-- NOTE: drivers update status through an RPC (to be added) so they cannot change price or addresses.

create policy "locations read" on driver_locations for select using (
  is_admin() or driver_id = auth.uid()
  or exists (select 1 from orders o where o.id = order_id and o.customer_id = auth.uid()));
create policy "locations insert" on driver_locations for insert with check (
  driver_id = auth.uid() and exists (
    select 1 from orders o where o.id = order_id and o.driver_id = auth.uid()
    and o.status in ('driver_on_the_way','picked_up','in_transit')));

alter publication supabase_realtime add table driver_locations, orders;

-- ===== Added: profiles, driver RPC, optional privacy cleanup =====
create function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin insert into profiles(id) values (new.id); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

-- Drivers can only move THEIR order through these statuses (no price/address edits).
create function driver_set_status(p_order uuid, p_status order_status) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_status not in ('driver_on_the_way','picked_up','in_transit','delivered') then raise exception 'status not allowed'; end if;
  update orders set status = p_status where id = p_order and driver_id = auth.uid();
  if not found then raise exception 'not your order'; end if;
end $$;

-- Optional (enable the pg_cron extension first): delete driver GPS points after 7 days.
-- select cron.schedule('purge-locations','0 3 * * *',$$delete from driver_locations where recorded_at < now() - interval '7 days'$$);
-- To make someone a driver:  update profiles set role='driver', full_name='Name' where id='<user-id>';
